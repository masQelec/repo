# -*- coding: utf-8 -*-
#    Copyright (C) 2017 Sebastian Golasch (plugin.video.netflix)
#    Copyright (C) 2019 Stefano Gottardo - @CastagnaIT (original implementation module)
#    Data type conversion

#    SPDX-License-Identifier: MIT
#    See LICENSES/MIT.md for more information.
